
INSERT INTO AdventureCSV...Sales_Store#csv([CustomerID],[Name],[SalesPersonID],[Demographics],[rowguid],[ModifiedDate])
  Select  [CustomerID], [Name], [SalesPersonID], convert(NVARCHAR(MAX),[Demographics]), [rowguid], [ModifiedDate]
  FROM AdventureWorks.Sales.Store
  
INSERT INTO AdventureCSV...Production_ProductPhoto#csv([ProductPhotoID],[ThumbNailPhoto],[ThumbnailPhotoFileName],[LargePhoto],[LargePhotoFileName],[ModifiedDate])
  Select  [ProductPhotoID], convert(NVARCHAR(MAX),[ThumbNailPhoto]), [ThumbnailPhotoFileName], convert(NVARCHAR(MAX),[LargePhoto]), [LargePhotoFileName], [ModifiedDate]
  FROM AdventureWorks.Production.ProductPhoto
  
INSERT INTO AdventureCSV...Production_ProductProductPhoto#csv([ProductID],[ProductPhotoID],[Primary],[ModifiedDate])
  Select  [ProductID], [ProductPhotoID], [Primary], [ModifiedDate]
  FROM AdventureWorks.Production.ProductProductPhoto
  
INSERT INTO AdventureCSV...Sales_StoreContact#csv([CustomerID],[ContactID],[ContactTypeID],[rowguid],[ModifiedDate])
  Select  [CustomerID], [ContactID], [ContactTypeID], [rowguid], [ModifiedDate]
  FROM AdventureWorks.Sales.StoreContact
  
INSERT INTO AdventureCSV...Person_Address#csv([AddressID],[AddressLine1],[AddressLine2],[City],[StateProvinceID],[PostalCode],[rowguid],[ModifiedDate])
  Select  [AddressID], [AddressLine1], [AddressLine2], [City], [StateProvinceID], [PostalCode], [rowguid], [ModifiedDate]
  FROM AdventureWorks.Person.Address
  
INSERT INTO AdventureCSV...Production_ProductReview#csv([ProductReviewID],[ProductID],[ReviewerName],[ReviewDate],[EmailAddress],[Rating],[Comments],[ModifiedDate])
  Select  [ProductReviewID], [ProductID], [ReviewerName], [ReviewDate], [EmailAddress], [Rating], [Comments], [ModifiedDate]
  FROM AdventureWorks.Production.ProductReview
  
INSERT INTO AdventureCSV...Production_TransactionHistory#csv([TransactionID],[ProductID],[ReferenceOrderID],[ReferenceOrderLineID],[TransactionDate],[TransactionType],[Quantity],[ActualCost],[ModifiedDate])
  Select  [TransactionID], [ProductID], [ReferenceOrderID], [ReferenceOrderLineID], [TransactionDate], [TransactionType], [Quantity], [ActualCost], [ModifiedDate]
  FROM AdventureWorks.Production.TransactionHistory
  
INSERT INTO AdventureCSV...Person_AddressType#csv([AddressTypeID],[Name],[rowguid],[ModifiedDate])
  Select  [AddressTypeID], [Name], [rowguid], [ModifiedDate]
  FROM AdventureWorks.Person.AddressType
  
INSERT INTO AdventureCSV...Production_ProductSubcategory#csv([ProductSubcategoryID],[ProductCategoryID],[Name],[rowguid],[ModifiedDate])
  Select  [ProductSubcategoryID], [ProductCategoryID], [Name], [rowguid], [ModifiedDate]
  FROM AdventureWorks.Production.ProductSubcategory
  
INSERT INTO AdventureCSV...dbo_AWBuildVersion#csv([SystemInformationID],[Database Version],[VersionDate],[ModifiedDate])
  Select  [SystemInformationID], [Database Version], [VersionDate], [ModifiedDate]
  FROM AdventureWorks.dbo.AWBuildVersion
  
INSERT INTO AdventureCSV...Production_TransactionHistoryArchive#csv([TransactionID],[ProductID],[ReferenceOrderID],[ReferenceOrderLineID],[TransactionDate],[TransactionType],[Quantity],[ActualCost],[ModifiedDate])
  Select  [TransactionID], [ProductID], [ReferenceOrderID], [ReferenceOrderLineID], [TransactionDate], [TransactionType], [Quantity], [ActualCost], [ModifiedDate]
  FROM AdventureWorks.Production.TransactionHistoryArchive
  
INSERT INTO AdventureCSV...Purchasing_ProductVendor#csv([ProductID],[VendorID],[AverageLeadTime],[StandardPrice],[LastReceiptCost],[LastReceiptDate],[MinOrderQty],[MaxOrderQty],[OnOrderQty],[UnitMeasureCode],[ModifiedDate])
  Select  [ProductID], [VendorID], [AverageLeadTime], [StandardPrice], [LastReceiptCost], [LastReceiptDate], [MinOrderQty], [MaxOrderQty], [OnOrderQty], [UnitMeasureCode], [ModifiedDate]
  FROM AdventureWorks.Purchasing.ProductVendor
  
INSERT INTO AdventureCSV...Production_BillOfMaterials#csv([BillOfMaterialsID],[ProductAssemblyID],[ComponentID],[StartDate],[EndDate],[UnitMeasureCode],[BOMLevel],[PerAssemblyQty],[ModifiedDate])
  Select  [BillOfMaterialsID], [ProductAssemblyID], [ComponentID], [StartDate], [EndDate], [UnitMeasureCode], [BOMLevel], [PerAssemblyQty], [ModifiedDate]
  FROM AdventureWorks.Production.BillOfMaterials
  
INSERT INTO AdventureCSV...Production_UnitMeasure#csv([UnitMeasureCode],[Name],[ModifiedDate])
  Select  [UnitMeasureCode], [Name], [ModifiedDate]
  FROM AdventureWorks.Production.UnitMeasure
  
INSERT INTO AdventureCSV...Purchasing_Vendor#csv([VendorID],[AccountNumber],[Name],[CreditRating],[PreferredVendorStatus],[ActiveFlag],[PurchasingWebServiceURL],[ModifiedDate])
  Select  [VendorID], [AccountNumber], [Name], [CreditRating], [PreferredVendorStatus], [ActiveFlag], [PurchasingWebServiceURL], [ModifiedDate]
  FROM AdventureWorks.Purchasing.Vendor
  
INSERT INTO AdventureCSV...Purchasing_PurchaseOrderDetail#csv([PurchaseOrderID],[PurchaseOrderDetailID],[DueDate],[OrderQty],[ProductID],[UnitPrice],[LineTotal],[ReceivedQty],[RejectedQty],[StockedQty],[ModifiedDate])
  Select  [PurchaseOrderID], [PurchaseOrderDetailID], [DueDate], [OrderQty], [ProductID], [UnitPrice], [LineTotal], [ReceivedQty], [RejectedQty], [StockedQty], [ModifiedDate]
  FROM AdventureWorks.Purchasing.PurchaseOrderDetail
  
INSERT INTO AdventureCSV...Person_Contact#csv([ContactID],[NameStyle],[Title],[FirstName],[MiddleName],[LastName],[Suffix],[EmailAddress],[EmailPromotion],[Phone],[PasswordHash],[PasswordSalt],[AdditionalContactInfo],[rowguid],[ModifiedDate])
  Select  [ContactID], [NameStyle], [Title], [FirstName], [MiddleName], [LastName], [Suffix], [EmailAddress], [EmailPromotion], [Phone], [PasswordHash], [PasswordSalt], convert(NVARCHAR(MAX),[AdditionalContactInfo]), [rowguid], [ModifiedDate]
  FROM AdventureWorks.Person.Contact
  
INSERT INTO AdventureCSV...Purchasing_VendorAddress#csv([VendorID],[AddressID],[AddressTypeID],[ModifiedDate])
  Select  [VendorID], [AddressID], [AddressTypeID], [ModifiedDate]
  FROM AdventureWorks.Purchasing.VendorAddress
  
INSERT INTO AdventureCSV...Purchasing_VendorContact#csv([VendorID],[ContactID],[ContactTypeID],[ModifiedDate])
  Select  [VendorID], [ContactID], [ContactTypeID], [ModifiedDate]
  FROM AdventureWorks.Purchasing.VendorContact
  
INSERT INTO AdventureCSV...Purchasing_PurchaseOrderHeader#csv([PurchaseOrderID],[RevisionNumber],[Status],[EmployeeID],[VendorID],[ShipMethodID],[OrderDate],[ShipDate],[SubTotal],[TaxAmt],[Freight],[TotalDue],[ModifiedDate])
  Select  [PurchaseOrderID], [RevisionNumber], [Status], [EmployeeID], [VendorID], [ShipMethodID], [OrderDate], [ShipDate], [SubTotal], [TaxAmt], [Freight], [TotalDue], [ModifiedDate]
  FROM AdventureWorks.Purchasing.PurchaseOrderHeader
  
INSERT INTO AdventureCSV...Sales_ContactCreditCard#csv([ContactID],[CreditCardID],[ModifiedDate])
  Select  [ContactID], [CreditCardID], [ModifiedDate]
  FROM AdventureWorks.Sales.ContactCreditCard
  
INSERT INTO AdventureCSV...Production_WorkOrder#csv([WorkOrderID],[ProductID],[OrderQty],[StockedQty],[ScrappedQty],[StartDate],[EndDate],[DueDate],[ScrapReasonID],[ModifiedDate])
  Select  [WorkOrderID], [ProductID], [OrderQty], [StockedQty], [ScrappedQty], [StartDate], [EndDate], [DueDate], [ScrapReasonID], [ModifiedDate]
  FROM AdventureWorks.Production.WorkOrder
  
INSERT INTO AdventureCSV...Person_ContactType#csv([ContactTypeID],[Name],[ModifiedDate])
  Select  [ContactTypeID], [Name], [ModifiedDate]
  FROM AdventureWorks.Person.ContactType
  
INSERT INTO AdventureCSV...Sales_CountryRegionCurrency#csv([CountryRegionCode],[CurrencyCode],[ModifiedDate])
  Select  [CountryRegionCode], [CurrencyCode], [ModifiedDate]
  FROM AdventureWorks.Sales.CountryRegionCurrency
  
INSERT INTO AdventureCSV...Production_WorkOrderRouting#csv([WorkOrderID],[ProductID],[OperationSequence],[LocationID],[ScheduledStartDate],[ScheduledEndDate],[ActualStartDate],[ActualEndDate],[ActualResourceHrs],[PlannedCost],[ActualCost],[ModifiedDate])
  Select  [WorkOrderID], [ProductID], [OperationSequence], [LocationID], [ScheduledStartDate], [ScheduledEndDate], [ActualStartDate], [ActualEndDate], [ActualResourceHrs], [PlannedCost], [ActualCost], [ModifiedDate]
  FROM AdventureWorks.Production.WorkOrderRouting
  
INSERT INTO AdventureCSV...Person_CountryRegion#csv([CountryRegionCode],[Name],[ModifiedDate])
  Select  [CountryRegionCode], [Name], [ModifiedDate]
  FROM AdventureWorks.Person.CountryRegion
  
INSERT INTO AdventureCSV...Sales_CreditCard#csv([CreditCardID],[CardType],[CardNumber],[ExpMonth],[ExpYear],[ModifiedDate])
  Select  [CreditCardID], [CardType], [CardNumber], [ExpMonth], [ExpYear], [ModifiedDate]
  FROM AdventureWorks.Sales.CreditCard
  
INSERT INTO AdventureCSV...Production_Culture#csv([CultureID],[Name],[ModifiedDate])
  Select  [CultureID], [Name], [ModifiedDate]
  FROM AdventureWorks.Production.Culture
  
INSERT INTO AdventureCSV...Sales_Currency#csv([CurrencyCode],[Name],[ModifiedDate])
  Select  [CurrencyCode], [Name], [ModifiedDate]
  FROM AdventureWorks.Sales.Currency
  
INSERT INTO AdventureCSV...Sales_SalesOrderDetail#csv([SalesOrderID],[SalesOrderDetailID],[CarrierTrackingNumber],[OrderQty],[ProductID],[SpecialOfferID],[UnitPrice],[UnitPriceDiscount],[LineTotal],[rowguid],[ModifiedDate])
  Select  [SalesOrderID], [SalesOrderDetailID], [CarrierTrackingNumber], [OrderQty], [ProductID], [SpecialOfferID], [UnitPrice], [UnitPriceDiscount], [LineTotal], [rowguid], [ModifiedDate]
  FROM AdventureWorks.Sales.SalesOrderDetail
  
INSERT INTO AdventureCSV...Sales_CurrencyRate#csv([CurrencyRateID],[CurrencyRateDate],[FromCurrencyCode],[ToCurrencyCode],[AverageRate],[EndOfDayRate],[ModifiedDate])
  Select  [CurrencyRateID], [CurrencyRateDate], [FromCurrencyCode], [ToCurrencyCode], [AverageRate], [EndOfDayRate], [ModifiedDate]
  FROM AdventureWorks.Sales.CurrencyRate
  
INSERT INTO AdventureCSV...Sales_Customer#csv([CustomerID],[TerritoryID],[AccountNumber],[CustomerType],[rowguid],[ModifiedDate])
  Select  [CustomerID], [TerritoryID], [AccountNumber], [CustomerType], [rowguid], [ModifiedDate]
  FROM AdventureWorks.Sales.Customer
  
INSERT INTO AdventureCSV...Sales_SalesOrderHeader#csv([SalesOrderID],[RevisionNumber],[OrderDate],[DueDate],[ShipDate],[Status],[OnlineOrderFlag],[SalesOrderNumber],[PurchaseOrderNumber],[AccountNumber],[CustomerID],[ContactID],[SalesPersonID],[TerritoryID],[BillToAddressID],[ShipToAddressID],[ShipMethodID],[CreditCardID],[CreditCardApprovalCode],[CurrencyRateID],[SubTotal],[TaxAmt],[Freight],[TotalDue],[Comment],[rowguid],[ModifiedDate])
  Select  [SalesOrderID], [RevisionNumber], [OrderDate], [DueDate], [ShipDate], [Status], [OnlineOrderFlag], [SalesOrderNumber], [PurchaseOrderNumber], [AccountNumber], [CustomerID], [ContactID], [SalesPersonID], [TerritoryID], [BillToAddressID], [ShipToAddressID], [ShipMethodID], [CreditCardID], [CreditCardApprovalCode], [CurrencyRateID], [SubTotal], [TaxAmt], [Freight], [TotalDue], [Comment], [rowguid], [ModifiedDate]
  FROM AdventureWorks.Sales.SalesOrderHeader
  
INSERT INTO AdventureCSV...Sales_CustomerAddress#csv([CustomerID],[AddressID],[AddressTypeID],[rowguid],[ModifiedDate])
  Select  [CustomerID], [AddressID], [AddressTypeID], [rowguid], [ModifiedDate]
  FROM AdventureWorks.Sales.CustomerAddress
  
INSERT INTO AdventureCSV...HumanResources_Department#csv([DepartmentID],[Name],[GroupName],[ModifiedDate])
  Select  [DepartmentID], [Name], [GroupName], [ModifiedDate]
  FROM AdventureWorks.HumanResources.Department
  
INSERT INTO AdventureCSV...Production_Document#csv([DocumentID],[Title],[FileName],[FileExtension],[Revision],[ChangeNumber],[Status],[DocumentSummary],[Document],[ModifiedDate])
  Select  [DocumentID], [Title], [FileName], [FileExtension], [Revision], [ChangeNumber], [Status], [DocumentSummary], convert(NVARCHAR(MAX),[Document]), [ModifiedDate]
  FROM AdventureWorks.Production.Document
  
INSERT INTO AdventureCSV...dbo_PayGrades#csv([PayGradeCode],[Position])
  Select  [PayGradeCode], [Position]
  FROM AdventureWorks.dbo.PayGrades
  
INSERT INTO AdventureCSV...HumanResources_Employee#csv([EmployeeID],[NationalIDNumber],[ContactID],[LoginID],[ManagerID],[Title],[BirthDate],[MaritalStatus],[Gender],[HireDate],[SalariedFlag],[VacationHours],[SickLeaveHours],[CurrentFlag],[rowguid],[ModifiedDate])
  Select  [EmployeeID], [NationalIDNumber], [ContactID], [LoginID], [ManagerID], [Title], [BirthDate], [MaritalStatus], [Gender], [HireDate], [SalariedFlag], [VacationHours], [SickLeaveHours], [CurrentFlag], [rowguid], [ModifiedDate]
  FROM AdventureWorks.HumanResources.Employee
  
INSERT INTO AdventureCSV...dbo_Employees#csv([EmployeeID],[ManagerID],[PayGradeCode],[FirstName],[LastName])
  Select  [EmployeeID], [ManagerID], [PayGradeCode], [FirstName], [LastName]
  FROM AdventureWorks.dbo.Employees
  
INSERT INTO AdventureCSV...Sales_SalesOrderHeaderSalesReason#csv([SalesOrderID],[SalesReasonID],[ModifiedDate])
  Select  [SalesOrderID], [SalesReasonID], [ModifiedDate]
  FROM AdventureWorks.Sales.SalesOrderHeaderSalesReason
  
INSERT INTO AdventureCSV...Sales_SalesPerson#csv([SalesPersonID],[TerritoryID],[SalesQuota],[Bonus],[CommissionPct],[SalesYTD],[SalesLastYear],[rowguid],[ModifiedDate])
  Select  [SalesPersonID], [TerritoryID], [SalesQuota], [Bonus], [CommissionPct], [SalesYTD], [SalesLastYear], [rowguid], [ModifiedDate]
  FROM AdventureWorks.Sales.SalesPerson
  
INSERT INTO AdventureCSV...HumanResources_EmployeeAddress#csv([EmployeeID],[AddressID],[rowguid],[ModifiedDate])
  Select  [EmployeeID], [AddressID], [rowguid], [ModifiedDate]
  FROM AdventureWorks.HumanResources.EmployeeAddress
  
INSERT INTO AdventureCSV...HumanResources_EmployeeDepartmentHistory#csv([EmployeeID],[DepartmentID],[ShiftID],[StartDate],[EndDate],[ModifiedDate])
  Select  [EmployeeID], [DepartmentID], [ShiftID], [StartDate], [EndDate], [ModifiedDate]
  FROM AdventureWorks.HumanResources.EmployeeDepartmentHistory
  
INSERT INTO AdventureCSV...HumanResources_EmployeePayHistory#csv([EmployeeID],[RateChangeDate],[Rate],[PayFrequency],[ModifiedDate])
  Select  [EmployeeID], [RateChangeDate], [Rate], [PayFrequency], [ModifiedDate]
  FROM AdventureWorks.HumanResources.EmployeePayHistory
  
INSERT INTO AdventureCSV...Sales_justCreditcards#csv([creditcardID],[CardNumber])
  Select  [creditcardID], [CardNumber]
  FROM AdventureWorks.Sales.justCreditcards
  
INSERT INTO AdventureCSV...Sales_SalesPersonQuotaHistory#csv([SalesPersonID],[QuotaDate],[SalesQuota],[rowguid],[ModifiedDate])
  Select  [SalesPersonID], [QuotaDate], [SalesQuota], [rowguid], [ModifiedDate]
  FROM AdventureWorks.Sales.SalesPersonQuotaHistory
  
INSERT INTO AdventureCSV...Production_Illustration#csv([IllustrationID],[Diagram],[ModifiedDate])
  Select  [IllustrationID], convert(NVARCHAR(MAX),[Diagram]), [ModifiedDate]
  FROM AdventureWorks.Production.Illustration
  
INSERT INTO AdventureCSV...Sales_SalesReason#csv([SalesReasonID],[Name],[ReasonType],[ModifiedDate])
  Select  [SalesReasonID], [Name], [ReasonType], [ModifiedDate]
  FROM AdventureWorks.Sales.SalesReason
  
INSERT INTO AdventureCSV...Sales_Individual#csv([CustomerID],[ContactID],[Demographics],[ModifiedDate])
  Select  [CustomerID], [ContactID], convert(NVARCHAR(MAX),[Demographics]), [ModifiedDate]
  FROM AdventureWorks.Sales.Individual
  
INSERT INTO AdventureCSV...Person_vAdditionalContactInfo#csv([ContactID],[FirstName],[MiddleName],[LastName],[TelephoneNumber],[TelephoneSpecialInstructions],[Street],[City],[StateProvince],[PostalCode],[CountryRegion],[HomeAddressSpecialInstructions],[EMailAddress],[EMailSpecialInstructions],[EMailTelephoneNumber],[rowguid],[ModifiedDate])
  Select  [ContactID], [FirstName], [MiddleName], [LastName], [TelephoneNumber], [TelephoneSpecialInstructions], [Street], [City], [StateProvince], [PostalCode], [CountryRegion], [HomeAddressSpecialInstructions], [EMailAddress], [EMailSpecialInstructions], [EMailTelephoneNumber], [rowguid], [ModifiedDate]
  FROM AdventureWorks.Person.vAdditionalContactInfo
  
INSERT INTO AdventureCSV...Sales_SalesTaxRate#csv([SalesTaxRateID],[StateProvinceID],[TaxType],[TaxRate],[Name],[rowguid],[ModifiedDate])
  Select  [SalesTaxRateID], [StateProvinceID], [TaxType], [TaxRate], [Name], [rowguid], [ModifiedDate]
  FROM AdventureWorks.Sales.SalesTaxRate
  
INSERT INTO AdventureCSV...HumanResources_JobCandidate#csv([JobCandidateID],[EmployeeID],[Resume],[ModifiedDate])
  Select  [JobCandidateID], [EmployeeID], convert(NVARCHAR(MAX),[Resume]), [ModifiedDate]
  FROM AdventureWorks.HumanResources.JobCandidate
  
INSERT INTO AdventureCSV...HumanResources_vEmployee#csv([EmployeeID],[Title],[FirstName],[MiddleName],[LastName],[Suffix],[JobTitle],[Phone],[EmailAddress],[EmailPromotion],[AddressLine1],[AddressLine2],[City],[StateProvinceName],[PostalCode],[CountryRegionName],[AdditionalContactInfo])
  Select  [EmployeeID], [Title], [FirstName], [MiddleName], [LastName], [Suffix], [JobTitle], [Phone], [EmailAddress], [EmailPromotion], [AddressLine1], [AddressLine2], [City], [StateProvinceName], [PostalCode], [CountryRegionName], convert(NVARCHAR(MAX),[AdditionalContactInfo])
  FROM AdventureWorks.HumanResources.vEmployee
  
INSERT INTO AdventureCSV...HumanResources_vEmployeeDepartment#csv([EmployeeID],[Title],[FirstName],[MiddleName],[LastName],[Suffix],[JobTitle],[Department],[GroupName],[StartDate])
  Select  [EmployeeID], [Title], [FirstName], [MiddleName], [LastName], [Suffix], [JobTitle], [Department], [GroupName], [StartDate]
  FROM AdventureWorks.HumanResources.vEmployeeDepartment
  
INSERT INTO AdventureCSV...Production_Location#csv([LocationID],[Name],[CostRate],[Availability],[ModifiedDate])
  Select  [LocationID], [Name], [CostRate], [Availability], [ModifiedDate]
  FROM AdventureWorks.Production.Location
  
INSERT INTO AdventureCSV...HumanResources_vEmployeeDepartmentHistory#csv([EmployeeID],[Title],[FirstName],[MiddleName],[LastName],[Suffix],[Shift],[Department],[GroupName],[StartDate],[EndDate])
  Select  [EmployeeID], [Title], [FirstName], [MiddleName], [LastName], [Suffix], [Shift], [Department], [GroupName], [StartDate], [EndDate]
  FROM AdventureWorks.HumanResources.vEmployeeDepartmentHistory
  
INSERT INTO AdventureCSV...Sales_vIndividualCustomer#csv([CustomerID],[Title],[FirstName],[MiddleName],[LastName],[Suffix],[Phone],[EmailAddress],[EmailPromotion],[AddressType],[AddressLine1],[AddressLine2],[City],[StateProvinceName],[PostalCode],[CountryRegionName],[Demographics])
  Select  [CustomerID], [Title], [FirstName], [MiddleName], [LastName], [Suffix], [Phone], [EmailAddress], [EmailPromotion], [AddressType], [AddressLine1], [AddressLine2], [City], [StateProvinceName], [PostalCode], [CountryRegionName], convert(NVARCHAR(MAX),[Demographics])
  FROM AdventureWorks.Sales.vIndividualCustomer
  
INSERT INTO AdventureCSV...Sales_vIndividualDemographics#csv([CustomerID],[TotalPurchaseYTD],[DateFirstPurchase],[BirthDate],[MaritalStatus],[YearlyIncome],[Gender],[TotalChildren],[NumberChildrenAtHome],[Education],[Occupation],[HomeOwnerFlag],[NumberCarsOwned])
  Select  [CustomerID], [TotalPurchaseYTD], [DateFirstPurchase], [BirthDate], [MaritalStatus], [YearlyIncome], [Gender], [TotalChildren], [NumberChildrenAtHome], [Education], [Occupation], [HomeOwnerFlag], [NumberCarsOwned]
  FROM AdventureWorks.Sales.vIndividualDemographics
  
INSERT INTO AdventureCSV...Sales_SalesTerritory#csv([TerritoryID],[Name],[CountryRegionCode],[Group],[SalesYTD],[SalesLastYear],[CostYTD],[CostLastYear],[rowguid],[ModifiedDate])
  Select  [TerritoryID], [Name], [CountryRegionCode], [Group], [SalesYTD], [SalesLastYear], [CostYTD], [CostLastYear], [rowguid], [ModifiedDate]
  FROM AdventureWorks.Sales.SalesTerritory
  
INSERT INTO AdventureCSV...HumanResources_vJobCandidate#csv([JobCandidateID],[EmployeeID],[Name_Prefix],[Name_First],[Name_Middle],[Name_Last],[Name_Suffix],[Skills],[Addr_Type],[Addr_Loc_CountryRegion],[Addr_Loc_State],[Addr_Loc_City],[Addr_PostalCode],[EMail],[WebSite],[ModifiedDate])
  Select  [JobCandidateID], [EmployeeID], [Name.Prefix], [Name.First], [Name.Middle], [Name.Last], [Name.Suffix], [Skills], [Addr.Type], [Addr.Loc.CountryRegion], [Addr.Loc.State], [Addr.Loc.City], [Addr.PostalCode], [EMail], [WebSite], [ModifiedDate]
  FROM AdventureWorks.HumanResources.vJobCandidate
  
INSERT INTO AdventureCSV...HumanResources_vJobCandidateEmployment#csv([JobCandidateID],[Emp_StartDate],[Emp_EndDate],[Emp_OrgName],[Emp_JobTitle],[Emp_Responsibility],[Emp_FunctionCategory],[Emp_IndustryCategory],[Emp_Loc_CountryRegion],[Emp_Loc_State],[Emp_Loc_City])
  Select  [JobCandidateID], [Emp.StartDate], [Emp.EndDate], [Emp.OrgName], [Emp.JobTitle], [Emp.Responsibility], [Emp.FunctionCategory], [Emp.IndustryCategory], [Emp.Loc.CountryRegion], [Emp.Loc.State], [Emp.Loc.City]
  FROM AdventureWorks.HumanResources.vJobCandidateEmployment
  
INSERT INTO AdventureCSV...HumanResources_vJobCandidateEducation#csv([JobCandidateID],[Edu_Level],[Edu_StartDate],[Edu_EndDate],[Edu_Degree],[Edu_Major],[Edu_Minor],[Edu_GPA],[Edu_GPAScale],[Edu_School],[Edu_Loc_CountryRegion],[Edu_Loc_State],[Edu_Loc_City])
  Select  [JobCandidateID], [Edu.Level], [Edu.StartDate], [Edu.EndDate], [Edu.Degree], [Edu.Major], [Edu.Minor], [Edu.GPA], [Edu.GPAScale], [Edu.School], [Edu.Loc.CountryRegion], [Edu.Loc.State], [Edu.Loc.City]
  FROM AdventureWorks.HumanResources.vJobCandidateEducation
  
INSERT INTO AdventureCSV...Production_Product#csv([ProductID],[Name],[ProductNumber],[MakeFlag],[FinishedGoodsFlag],[Color],[SafetyStockLevel],[ReorderPoint],[StandardCost],[ListPrice],[Size],[SizeUnitMeasureCode],[WeightUnitMeasureCode],[Weight],[DaysToManufacture],[ProductLine],[Class],[Style],[ProductSubcategoryID],[ProductModelID],[SellStartDate],[SellEndDate],[DiscontinuedDate],[rowguid],[ModifiedDate])
  Select  [ProductID], [Name], [ProductNumber], [MakeFlag], [FinishedGoodsFlag], [Color], [SafetyStockLevel], [ReorderPoint], [StandardCost], [ListPrice], [Size], [SizeUnitMeasureCode], [WeightUnitMeasureCode], [Weight], [DaysToManufacture], [ProductLine], [Class], [Style], [ProductSubcategoryID], [ProductModelID], [SellStartDate], [SellEndDate], [DiscontinuedDate], [rowguid], [ModifiedDate]
  FROM AdventureWorks.Production.Product
  
INSERT INTO AdventureCSV...Production_vProductAndDescription#csv([ProductID],[Name],[ProductModel],[CultureID],[Description])
  Select  [ProductID], [Name], [ProductModel], [CultureID], [Description]
  FROM AdventureWorks.Production.vProductAndDescription
  
INSERT INTO AdventureCSV...Production_vProductModelCatalogDescription#csv([ProductModelID],[Name],[Summary],[Manufacturer],[Copyright],[ProductURL],[WarrantyPeriod],[WarrantyDescription],[NoOfYears],[MaintenanceDescription],[Wheel],[Saddle],[Pedal],[BikeFrame],[Crankset],[PictureAngle],[PictureSize],[ProductPhotoID],[Material],[Color],[ProductLine],[Style],[RiderExperience],[rowguid],[ModifiedDate])
  Select  [ProductModelID], [Name], [Summary], [Manufacturer], [Copyright], [ProductURL], [WarrantyPeriod], [WarrantyDescription], [NoOfYears], [MaintenanceDescription], [Wheel], [Saddle], [Pedal], [BikeFrame], [Crankset], [PictureAngle], [PictureSize], [ProductPhotoID], [Material], [Color], [ProductLine], [Style], [RiderExperience], [rowguid], [ModifiedDate]
  FROM AdventureWorks.Production.vProductModelCatalogDescription
  
INSERT INTO AdventureCSV...Production_vProductModelInstructions#csv([ProductModelID],[Name],[Instructions],[LocationID],[SetupHours],[MachineHours],[LaborHours],[LotSize],[Step],[rowguid],[ModifiedDate])
  Select  [ProductModelID], [Name], [Instructions], [LocationID], [SetupHours], [MachineHours], [LaborHours], [LotSize], [Step], [rowguid], [ModifiedDate]
  FROM AdventureWorks.Production.vProductModelInstructions
  
INSERT INTO AdventureCSV...Sales_vSalesPerson#csv([SalesPersonID],[Title],[FirstName],[MiddleName],[LastName],[Suffix],[JobTitle],[Phone],[EmailAddress],[EmailPromotion],[AddressLine1],[AddressLine2],[City],[StateProvinceName],[PostalCode],[CountryRegionName],[TerritoryName],[TerritoryGroup],[SalesQuota],[SalesYTD],[SalesLastYear])
  Select  [SalesPersonID], [Title], [FirstName], [MiddleName], [LastName], [Suffix], [JobTitle], [Phone], [EmailAddress], [EmailPromotion], [AddressLine1], [AddressLine2], [City], [StateProvinceName], [PostalCode], [CountryRegionName], [TerritoryName], [TerritoryGroup], [SalesQuota], [SalesYTD], [SalesLastYear]
  FROM AdventureWorks.Sales.vSalesPerson
  
INSERT INTO AdventureCSV...Sales_vSalesPersonSalesByFiscalYears#csv([SalesPersonID],[FullName],[Title],[SalesTerritory],[2002],[2003],[2004])
  Select  [SalesPersonID], [FullName], [Title], [SalesTerritory], [2002], [2003], [2004]
  FROM AdventureWorks.Sales.vSalesPersonSalesByFiscalYears
  
INSERT INTO AdventureCSV...Person_vStateProvinceCountryRegion#csv([StateProvinceID],[StateProvinceCode],[IsOnlyStateProvinceFlag],[StateProvinceName],[TerritoryID],[CountryRegionCode],[CountryRegionName])
  Select  [StateProvinceID], [StateProvinceCode], [IsOnlyStateProvinceFlag], [StateProvinceName], [TerritoryID], [CountryRegionCode], [CountryRegionName]
  FROM AdventureWorks.Person.vStateProvinceCountryRegion
  
INSERT INTO AdventureCSV...Sales_vStoreWithDemographics#csv([CustomerID],[Name],[ContactType],[Title],[FirstName],[MiddleName],[LastName],[Suffix],[Phone],[EmailAddress],[EmailPromotion],[AddressType],[AddressLine1],[AddressLine2],[City],[StateProvinceName],[PostalCode],[CountryRegionName],[AnnualSales],[AnnualRevenue],[BankName],[BusinessType],[YearOpened],[Specialty],[SquareFeet],[Brands],[Internet],[NumberEmployees])
  Select  [CustomerID], [Name], [ContactType], [Title], [FirstName], [MiddleName], [LastName], [Suffix], [Phone], [EmailAddress], [EmailPromotion], [AddressType], [AddressLine1], [AddressLine2], [City], [StateProvinceName], [PostalCode], [CountryRegionName], [AnnualSales], [AnnualRevenue], [BankName], [BusinessType], [YearOpened], [Specialty], [SquareFeet], [Brands], [Internet], [NumberEmployees]
  FROM AdventureWorks.Sales.vStoreWithDemographics
  
INSERT INTO AdventureCSV...Purchasing_vVendor#csv([VendorID],[Name],[ContactType],[Title],[FirstName],[MiddleName],[LastName],[Suffix],[Phone],[EmailAddress],[EmailPromotion],[AddressLine1],[AddressLine2],[City],[StateProvinceName],[PostalCode],[CountryRegionName])
  Select  [VendorID], [Name], [ContactType], [Title], [FirstName], [MiddleName], [LastName], [Suffix], [Phone], [EmailAddress], [EmailPromotion], [AddressLine1], [AddressLine2], [City], [StateProvinceName], [PostalCode], [CountryRegionName]
  FROM AdventureWorks.Purchasing.vVendor
  
INSERT INTO AdventureCSV...Sales_SalesTerritoryHistory#csv([SalesPersonID],[TerritoryID],[StartDate],[EndDate],[rowguid],[ModifiedDate])
  Select  [SalesPersonID], [TerritoryID], [StartDate], [EndDate], [rowguid], [ModifiedDate]
  FROM AdventureWorks.Sales.SalesTerritoryHistory
  
INSERT INTO AdventureCSV...Production_ScrapReason#csv([ScrapReasonID],[Name],[ModifiedDate])
  Select  [ScrapReasonID], [Name], [ModifiedDate]
  FROM AdventureWorks.Production.ScrapReason
  
INSERT INTO AdventureCSV...HumanResources_Shift#csv([ShiftID],[Name],[StartTime],[EndTime],[ModifiedDate])
  Select  [ShiftID], [Name], [StartTime], [EndTime], [ModifiedDate]
  FROM AdventureWorks.HumanResources.Shift
  
INSERT INTO AdventureCSV...Production_ProductCategory#csv([ProductCategoryID],[Name],[rowguid],[ModifiedDate])
  Select  [ProductCategoryID], [Name], [rowguid], [ModifiedDate]
  FROM AdventureWorks.Production.ProductCategory
  
INSERT INTO AdventureCSV...Purchasing_ShipMethod#csv([ShipMethodID],[Name],[ShipBase],[ShipRate],[rowguid],[ModifiedDate])
  Select  [ShipMethodID], [Name], [ShipBase], [ShipRate], [rowguid], [ModifiedDate]
  FROM AdventureWorks.Purchasing.ShipMethod
  
INSERT INTO AdventureCSV...Production_ProductCostHistory#csv([ProductID],[StartDate],[EndDate],[StandardCost],[ModifiedDate])
  Select  [ProductID], [StartDate], [EndDate], [StandardCost], [ModifiedDate]
  FROM AdventureWorks.Production.ProductCostHistory
  
INSERT INTO AdventureCSV...Production_ProductDescription#csv([ProductDescriptionID],[Description],[rowguid],[ModifiedDate])
  Select  [ProductDescriptionID], [Description], [rowguid], [ModifiedDate]
  FROM AdventureWorks.Production.ProductDescription
  
INSERT INTO AdventureCSV...Sales_ShoppingCartItem#csv([ShoppingCartItemID],[ShoppingCartID],[Quantity],[ProductID],[DateCreated],[ModifiedDate])
  Select  [ShoppingCartItemID], [ShoppingCartID], [Quantity], [ProductID], [DateCreated], [ModifiedDate]
  FROM AdventureWorks.Sales.ShoppingCartItem
  
INSERT INTO AdventureCSV...Production_ProductDocument#csv([ProductID],[DocumentID],[ModifiedDate])
  Select  [ProductID], [DocumentID], [ModifiedDate]
  FROM AdventureWorks.Production.ProductDocument
  
INSERT INTO AdventureCSV...Production_ProductInventory#csv([ProductID],[LocationID],[Shelf],[Bin],[Quantity],[rowguid],[ModifiedDate])
  Select  [ProductID], [LocationID], [Shelf], [Bin], [Quantity], [rowguid], [ModifiedDate]
  FROM AdventureWorks.Production.ProductInventory
  
INSERT INTO AdventureCSV...Sales_SpecialOffer#csv([SpecialOfferID],[Description],[DiscountPct],[Type],[Category],[StartDate],[EndDate],[MinQty],[MaxQty],[rowguid],[ModifiedDate])
  Select  [SpecialOfferID], [Description], [DiscountPct], [Type], [Category], [StartDate], [EndDate], [MinQty], [MaxQty], [rowguid], [ModifiedDate]
  FROM AdventureWorks.Sales.SpecialOffer
  
INSERT INTO AdventureCSV...dbo_Product#csv([ProductID],[ProductName],[CategoryID],[ProductAmt])
  Select  [ProductID], [ProductName], [CategoryID], [ProductAmt]
  FROM AdventureWorks.dbo.Product
  
INSERT INTO AdventureCSV...dbo_testSentences#csv([TheKey],[theSentence])
  Select  [TheKey], [theSentence]
  FROM AdventureWorks.dbo.testSentences
  
INSERT INTO AdventureCSV...Production_ProductListPriceHistory#csv([ProductID],[StartDate],[EndDate],[ListPrice],[ModifiedDate])
  Select  [ProductID], [StartDate], [EndDate], [ListPrice], [ModifiedDate]
  FROM AdventureWorks.Production.ProductListPriceHistory
  
INSERT INTO AdventureCSV...Sales_SpecialOfferProduct#csv([SpecialOfferID],[ProductID],[rowguid],[ModifiedDate])
  Select  [SpecialOfferID], [ProductID], [rowguid], [ModifiedDate]
  FROM AdventureWorks.Sales.SpecialOfferProduct
  
INSERT INTO AdventureCSV...Production_ProductModel#csv([ProductModelID],[Name],[CatalogDescription],[Instructions],[rowguid],[ModifiedDate])
  Select  [ProductModelID], [Name], convert(NVARCHAR(MAX),[CatalogDescription]), convert(NVARCHAR(MAX),[Instructions]), [rowguid], [ModifiedDate]
  FROM AdventureWorks.Production.ProductModel
  
INSERT INTO AdventureCSV...Person_StateProvince#csv([StateProvinceID],[StateProvinceCode],[CountryRegionCode],[IsOnlyStateProvinceFlag],[Name],[TerritoryID],[rowguid],[ModifiedDate])
  Select  [StateProvinceID], [StateProvinceCode], [CountryRegionCode], [IsOnlyStateProvinceFlag], [Name], [TerritoryID], [rowguid], [ModifiedDate]
  FROM AdventureWorks.Person.StateProvince
  
INSERT INTO AdventureCSV...Production_ProductModelIllustration#csv([ProductModelID],[IllustrationID],[ModifiedDate])
  Select  [ProductModelID], [IllustrationID], [ModifiedDate]
  FROM AdventureWorks.Production.ProductModelIllustration
  
INSERT INTO AdventureCSV...dbo_DatabaseLog#csv([DatabaseLogID],[PostTime],[DatabaseUser],[Event],[Schema],[Object],[TSQL],[XmlEvent])
  Select  [DatabaseLogID], [PostTime], [DatabaseUser], [Event], [Schema], [Object], [TSQL], convert(NVARCHAR(MAX),[XmlEvent])
  FROM AdventureWorks.dbo.DatabaseLog
  
INSERT INTO AdventureCSV...Production_ProductModelProductDescriptionCulture#csv([ProductModelID],[ProductDescriptionID],[CultureID],[ModifiedDate])
  Select  [ProductModelID], [ProductDescriptionID], [CultureID], [ModifiedDate]
  FROM AdventureWorks.Production.ProductModelProductDescriptionCulture
  
INSERT INTO AdventureCSV...dbo_ErrorLog#csv([ErrorLogID],[ErrorTime],[UserName],[ErrorNumber],[ErrorSeverity],[ErrorState],[ErrorProcedure],[ErrorLine],[ErrorMessage])
  Select  [ErrorLogID], [ErrorTime], [UserName], [ErrorNumber], [ErrorSeverity], [ErrorState], [ErrorProcedure], [ErrorLine], [ErrorMessage]
  FROM AdventureWorks.dbo.ErrorLog
  
